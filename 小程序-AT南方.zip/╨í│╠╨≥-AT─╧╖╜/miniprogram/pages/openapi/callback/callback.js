// miniprogram/pages/openapi/callback/callback.js
Page({

  data: {

  },

  onLoad: function (options) {

  },

  onCustomerServiceButtonClick(e) {
    console.log(e)
  },
})
