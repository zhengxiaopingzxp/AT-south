// miniprogram/pages/home/information-filter/information-filter.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sourceTag: [
      ['校方',false],
      ['院系',false],
      ['社团',false],
      ['其他',false]
    ],
    collegeTag: [
      ['文学与传媒学院',false],
      ['护理与健康学院',false],
      ['艺术设计与创意产业系',false],
      ['电气与计算机工程学院',false],
      ['云康医学与健康学院',false],
      ['综合素养学部',false],
      ['马克思主义学院',false],
      ['外国语学院',false],
      ['会计学院',false],
      ['达人书院',false],
      ['公共管理学院',false],
      ['音乐系',false],
      ['大学英语教学中心',false],
      ['商学院',false],
      ['政商研究院',false],
      ['体育教学中心',false],
      ['继续教育学院',false]
    ],
    timeTag: [
      ['最近三天',false],
      ['一周前',false],
      ['半个月前',false],
      ['一个月前',false],
      ['三个月前',false],
      ['半年前',false],
      ['一年前',false]
    ],
    
    selectTag:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})