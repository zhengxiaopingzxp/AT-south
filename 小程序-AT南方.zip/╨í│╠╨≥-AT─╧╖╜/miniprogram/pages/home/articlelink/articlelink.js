// miniprogram/pages/home/articlelink/articlelink.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    webViewSrc:"https://mp.weixin.qq.com/s?__biz=MzI0NzkxMjAyNA==&tempkey=MTEwN19GMzJTdUVvalUyYWhwR09iYnQwcjI4X2RmMGd6bUUwMjF0cVhKRkFWSmkwQ01jRW9JMHpma0NXckJPT1NSSmotZm5UNnAybm5HWkk3dkFha0Z3LUdRaDZ2ckJIS2l3YzV4YzQ2NndqS1hHQklQd1Jkby0tWlk3blI1MUhqZkdudHdmaWp4RlhkaXBBMnZLcHhoUW9Ga1lEWTNNazdoOGI5Tk1BUUp3fn4%3D&chksm=69a982245ede0b32318dbadae5ebfd5cc716c84149bee9f9d8e39df1ffb74d78d1c948b2c8d6#rd"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})