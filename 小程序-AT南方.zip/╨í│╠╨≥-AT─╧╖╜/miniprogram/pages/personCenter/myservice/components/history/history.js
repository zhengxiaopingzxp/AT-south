// pages/personCenter/myservice/components/history/history.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    title:[{
      time:'今天',
      src1:'cloud://zjxy-lusmb.7a6a-zjxy-lusmb-1302377032/images/personCenter/myservice/image_history_2.png',
      url1:'',
      text1_1:'中山大学南方学院关于2021年寒假放假安排的通知',
      text1_2:'中山大学南方学院',
      src2:'cloud://zjxy-lusmb.7a6a-zjxy-lusmb-1302377032/images/personCenter/myservice/image_history_1.png',
      url2:'',
      text2_1:'郭怡',
      text2_2:'大家好，这里想问问学长姐《产品的视角》《简约至上》《用户体验要素》《交互设计沉思录》的...'
      },{
        time:'2021年2月1日',
        src1:'cloud://zjxy-lusmb.7a6a-zjxy-lusmb-1302377032/images/personCenter/myservice/image_history_2.png',
        url1:'',
        text1_1:'中山大学南方学院关于2021年寒假放假安排的通知',
        text1_2:'中山大学南方学院',
        src2:'cloud://zjxy-lusmb.7a6a-zjxy-lusmb-1302377032/images/personCenter/myservice/image_history_1.png',
        url2:'',
        text2_1:'郭怡',
        text2_2:'大家好，这里想问问学长姐《产品的视角》《简约至上》《用户体验要素》《交互设计沉思录》的...'
        }
    ]
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
